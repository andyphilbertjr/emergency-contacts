export const contacts = [
    {
        id: 1, 
        name: 'David',
        address: '121 something st.',
        phone: '570-789-1234',
        email: 'something@idk.com'
    },
    {
        id: 2, 
        name: 'Lance',
        address: '121 something st.',
        phone: '570-789-1234',
        email: 'something@idk.com'
    },
    {
        id: 3, 
        name: 'Alex',
        address: '121 something st.',
        phone: '570-789-1234',
        email: 'something@idk.com'
    },
    {
        id: 4, 
        name: 'Terrance',
        address: '121 something st.',
        phone: '570-789-1234',
        email: 'something@idk.com'
    },
]